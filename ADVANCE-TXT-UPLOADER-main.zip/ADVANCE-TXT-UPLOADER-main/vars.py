# Don't Remove Credit Tg - @Naveen0125
# Ask Doubt on telegram @naveen0125

from os import environ

API_ID = int(environ.get("API_ID", "24929898")) #Replace with your api id
API_HASH = environ.get("API_HASH", "f5fc8d628795f4886dcd74bb8102c7ea") #Replace with your api hash
BOT_TOKEN = environ.get("BOT_TOKEN", "7800155577:AAGnytLYlB9iTrodDVC1ZK4NQivqLXxACZ0") #Replace with your bot token
